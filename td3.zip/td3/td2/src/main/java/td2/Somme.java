package td2;

@FunctionalInterface
public interface Somme<T> {
    T somme(T v1, T v2);
}
