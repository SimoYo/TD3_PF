# TD3

donnez ici vos réponses au TD3, tout ce qui ne peut pas être mis directement sous forme de code en modifiant td1 et td2.

## Exercice 1

### Question 1

### Question 2

### Question 3

## Exercice 2

### Question 1
